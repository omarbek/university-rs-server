CREATE VIEW v_scientific_activity AS SELECT scient_act.id,
    empl_scient.employee_id,
    scient_act.scientific_activity_type_id,
    scient_act_type.type_name AS scientific_activity_type_name,
    empl_scient.topic,
    scient_act.begin_date,
    scient_act.end_date
   FROM ((scientific_activity scient_act
     JOIN employee_scientific empl_scient ON ((scient_act.id = empl_scient.id)))
     JOIN scientific_activity_type scient_act_type ON ((scient_act.scientific_activity_type_id = scient_act_type.id)));
