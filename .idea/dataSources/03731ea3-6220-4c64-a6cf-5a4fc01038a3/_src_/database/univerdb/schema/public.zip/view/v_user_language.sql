CREATE VIEW v_user_language AS SELECT usr_lang.id,
    usr_lang.user_id,
    usr_lang.language_id,
    lang.lang_name,
    usr_lang.language_level_id,
    lang_lvl.level_name
   FROM ((user_language usr_lang
     JOIN language lang ON ((usr_lang.language_id = lang.id)))
     JOIN language_level lang_lvl ON ((usr_lang.language_level_id = lang_lvl.id)));
