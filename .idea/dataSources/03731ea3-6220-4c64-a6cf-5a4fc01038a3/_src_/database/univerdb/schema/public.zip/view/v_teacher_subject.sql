CREATE VIEW v_teacher_subject AS SELECT teacher_subject.id,
    teacher_subject.employee_id,
    subj.name_ru AS subject_name,
    subj.code AS subject_code,
    teacher_subject.fall,
    teacher_subject.spring,
    teacher_subject.summer,
    teacher_subject.load_per_hours
   FROM (teacher_subject teacher_subject
     JOIN subject subj ON ((teacher_subject.subject_id = subj.id)));
