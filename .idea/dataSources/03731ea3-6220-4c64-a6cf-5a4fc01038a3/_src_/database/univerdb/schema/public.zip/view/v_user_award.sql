CREATE VIEW v_user_award AS SELECT usr_award.id,
    usr_award.user_id,
    usr_award.award_id,
    award.award_name
   FROM (user_award usr_award
     JOIN award award ON ((usr_award.award_id = award.id)));
