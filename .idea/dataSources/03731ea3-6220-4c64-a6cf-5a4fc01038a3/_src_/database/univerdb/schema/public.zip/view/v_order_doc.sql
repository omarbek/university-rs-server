CREATE VIEW v_order_doc AS SELECT order_doc.id,
    usr_doc.user_id,
    usr_doc.document_no,
    order_doc.order_type_id,
    order_type.type_name AS order_type_name,
    order_doc.study_year_id,
    study_year.study_year,
    usr_doc.issue_date,
    usr_doc.expire_date,
    order_doc.descr,
    order_doc.hide_transcript,
    usr_doc.deleted
   FROM (((order_doc order_doc
     JOIN user_document usr_doc ON ((order_doc.id = usr_doc.id)))
     JOIN order_type order_type ON ((order_doc.order_type_id = order_type.id)))
     LEFT JOIN study_year study_year ON ((order_doc.study_year_id = study_year.id)));
